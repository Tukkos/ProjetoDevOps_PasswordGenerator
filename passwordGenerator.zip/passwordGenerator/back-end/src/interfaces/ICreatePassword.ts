export interface ICreatePassword {
  length: number;
}
